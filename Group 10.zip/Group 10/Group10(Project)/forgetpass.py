import os
from tkinter import *
from tkinter import Button
import mysql.connector
from PIL import Image, ImageTk

window = Tk()
window.title("Create New Password")

image1 = Image.open("E:/Python Project/societyProject/img/five.jpeg")
bgImg = ImageTk.PhotoImage(image1)

mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password="root",
  database="society"
)

def login():
    window.destroy()
    os.system("py login.py")
    return True

def save():
    mycursor = mydb.cursor()
    mycursor.execute("update user set password='" + varPassword.get() + "' where username='" + varUsername.get() + "'")
    mydb.commit()

backgroundLabel = Label(window, image=bgImg)
backgroundLabel.place(x=0, y=0, relheight=1, relwidth=1)


blankLabel = Label(window, text="  ")
fopLabel= Label(window, text="Forgot Password", font=("Arial Bold", 10))
useerLabel= Label(window, text="Username")
passwordLabel = Label(window, text="New Password")

varUsername = StringVar()
varPassword = StringVar()

txtusername = Entry(window, textvariable=varUsername)
txtPass = Entry(window, textvariable=varPassword)

btnCreate = Button(text="Update", command=save)
btnLogin = Button(text="Login", command=login)

# Set anchor to center for all widgets

fopLabel.grid(row=0, column=2)
useerLabel.grid(row=1,column=1)
txtusername.grid(row=1,column=2)
passwordLabel.grid(row=2, column=1)
txtPass.grid(row=2, column=2)
btnCreate.grid(row=5, column=1)
btnLogin.grid(row=5, column=2)


window.geometry('400x400')
window.mainloop()