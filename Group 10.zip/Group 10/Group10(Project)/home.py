import os
import sys
from tkinter import *
from PIL import Image, ImageTk

window = Tk()
window.title("Welcome to Society Hub")

image1 = Image.open("E:/Python Project/societyProject/img/five.jpeg")
bgImg = ImageTk.PhotoImage(image1)

def openMmemberInfo():
    window.destroy()
    os.system("py memberInfo.py " + user)

def openReceipt():
    window.destroy()
    os.system("py reciept.py " + user)

def openRegisterComplaint():
    window.destroy()
    os.system("py registerComplaint.py " + user)

def openViewNotice():
    window.destroy()
    os.system("py viewNotice.py " + user)

def openreqs():
    window.destroy()
    os.system("py reqs.py " + user)

backgroundLabel = Label(window, image=bgImg)
backgroundLabel.place(x=0, y=0, relheight=1, relwidth=1)

btnMemberInfo = Button(text="MemberInfo", command=openMmemberInfo)
btnReceipt = Button(text="Receipt", command=openReceipt)
btnRegisterComplaint = Button(text="RegisterComplaint", command=openRegisterComplaint)
btnViewNotice = Button(text="View Notice", command=openViewNotice)
btnreq = Button(text="Request", command=openreqs)

if len(sys.argv) > 1:
    user = sys.argv[1]
else:
    user = ""

btnMemberInfo.grid(row=0, column=0, padx=5, pady=5, sticky=N)
btnReceipt.grid(row=2, column=0, padx=5, pady=5, sticky=N)
btnRegisterComplaint.grid(row=3, column=0, padx=5, pady=5, sticky=N)
btnViewNotice.grid(row=4, column=0, padx=5, pady=5, sticky=N)
btnreq.grid(row=5, column=0, padx=5, pady=5, sticky=N)

# Set the maximum columnspan to center the buttons
max_colspan = 2
for col in range(max_colspan):
    window.columnconfigure(col, weight=1)
window.rowconfigure(6, weight=1)

# Set the buttons to span multiple columns and center them
btnMemberInfo.grid(columnspan=max_colspan)
btnReceipt.grid(columnspan=max_colspan)
btnRegisterComplaint.grid(columnspan=max_colspan)
btnViewNotice.grid(columnspan=max_colspan)
btnreq.grid(columnspan=max_colspan)

window.geometry('400x400')
window.mainloop()
