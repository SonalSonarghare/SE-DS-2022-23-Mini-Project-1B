import os
import sys
import datetime
import mysql.connector
from tkinter import *
from PIL import Image, ImageTk

window = Tk()
window.title("Society Hub:Register A Complaint")

image1 = Image.open("E:/Python Project/societyProject/img/five.jpeg")
bgImg = ImageTk.PhotoImage(image1)

society_label = Label(window, text="ABC Society", font=("Arial Bold", 17))
address_label = Label(window, text="Ghodbunder Road, Thane West, Thane, Maharashtra 400607", font=("Arial", 8))

mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password="root",
  database="society"
)

def openHome():
    window.destroy()
    os.system("py home.py " + user)
    return True


def save():
    mycursor = mydb.cursor()
    current_date = StringVar()
    current_date = datetime.date.today()
    print(current_date)
    mycursor.execute("insert into complaint(user, title, description,date) values('"+ user + "', '" + title.get() + "', '" + txtAreaDescription.get("1.0", "end-1c") + "', '" + str(current_date) + "' )")
    mydb.commit()

backgroundLabel = Label(window, image=bgImg)
backgroundLabel.place(x=0, y=0, relheight=1, relwidth=1)

blankLabel = Label(window, text="  ")
comLabel=Label(window, text="Register Complaint", font=("Arial Bold", 8))
titleLabel = Label(window, text="Title")
descriptionLabel = Label(window, text="Description")

title = StringVar()
description = StringVar()

if len(sys.argv) > 1:
    user = sys.argv[1]
else:
    user = ""

txtTitle = Entry(window, textvariable=title)
#txtDescription = Entry(window, textvariable=description)
txtAreaDescription = Text(window, height=5, width=18)

btnSave = Button(window, text="Save", command=save)
btnHome = Button(window, text="Home", command=openHome)

society_label.grid(row=1, column=1, columnspan=2)
address_label.grid(row=2, column=1, columnspan=2)
comLabel.grid(row=1, column=1)
titleLabel.grid(row=3, column=1)
txtTitle.grid(row=3, column=2)
descriptionLabel.grid(row=4, column=1)
#txtDescription.grid(row=4, column=2)
txtAreaDescription.grid(row=4, column=2)
btnSave.grid(row=5, column=1)
btnHome.grid(row=5, column=2)

window.geometry('400x400')
window.mainloop()