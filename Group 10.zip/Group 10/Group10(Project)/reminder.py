import smtplib
import os
import sys
import datetime
import mysql.connector
from tkinter import *
from PIL import Image, ImageTk



window = Tk()
window.title("Society Hub:Reminder")

image1 = Image.open("E:/Python Project/societyProject/img/five.jpeg")
bgImg = ImageTk.PhotoImage(image1)

mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password="root",
  database="society"
)

backgroundLabel = Label(window, image=bgImg)
backgroundLabel.place(x=0, y=0, relheight=1, relwidth=1)


def openHome():
    window.destroy()
    os.system("py home.py " + user)
    return True


def getDetail():
    mycursor = mydb.cursor()
    mycursor.execute(
        "select owner1, email from members where flatno='" + flatno.get() + "'")

    myresult = mycursor.fetchall()

    ownername = ""
    emailId = ""
    for x in myresult:
        ownername = x[0]
        emailId = x[1]
    name.set(ownername)
    email.set(emailId)

def save():
    # creates SMTP session
    s = smtplib.SMTP('smtp.gmail.com', 587)

    # start TLS for security
    s.starttls()

    # app password: hgscfpziistxcnvp
    # Authentication
    s.login("padelkarurvi@gmail.com", "hgscfpziistxcnvp")

    # message to be sent
    message = 'Subject: {}\n\n{}'.format("Reminder",  emailbody.get())

    # sending the mail
    s.sendmail("padelkarurvi@gmail.com", email.get(), message)

    # terminating the session
    s.quit()


blankLabel = Label(window, text="  ")
flatNoLabel = Label(window, text="Flat No")
nameLabel = Label(window, text="Name")
titleLabel = Label(window, text="Email id")
descriptionLabel = Label(window, text="Email body")

flatno = StringVar()
name = StringVar()
email = StringVar()
emailbody = StringVar()

if len(sys.argv) > 1:
    user = sys.argv[1]
else:
    user = ""

txtFlatNo = Entry(window, textvariable=flatno)
txtName = Entry(window, textvariable=name, state="disabled")
txtEmailId = Entry(window, textvariable=email, state="disabled")
txtEmailBody = Entry(window, textvariable=emailbody)

btnGet = Button(window, text="Get", command=getDetail)
btnSave = Button(window, text="Save", command=save)
btnHome = Button(window, text="Home", command=openHome)

blankLabel.grid(row=1, column=1)
flatNoLabel.grid(row=2, column=1)
txtFlatNo.grid(row=2, column=2)
nameLabel.grid(row=3, column=1)
txtName.grid(row=3, column=2)
titleLabel.grid(row=4, column=1)
txtEmailId.grid(row=4, column=2)
descriptionLabel.grid(row=5, column=1)
txtEmailBody.grid(row=5, column=2)
btnGet.grid(row=6, column=1)
btnSave.grid(row=6, column=2)
btnHome.grid(row=6, column=3)

window.geometry('400x400')
window.mainloop()