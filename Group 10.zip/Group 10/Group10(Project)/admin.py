import tkinter as tk
from tkinter import *
import os
import sys
from PIL import Image, ImageTk

window = Tk()
window.title("Welcome to Society Hub")

image1 = Image.open("E:/Python Project/societyProject/img/four.jpeg")
bgImg = ImageTk.PhotoImage(image1)

def openManageMember():
    window.destroy()
    os.system("py registerMember.py " + user)
    return True

def openAddNotice():
    window.destroy()
    os.system("py addNotice.py " + user)
    return True

def openViewComplaints():
    window.destroy()
    os.system("py viewComplaints.py " + user)
    return True

def openBill():
    window.destroy()
    os.system("py bill.py " + user)
    return True

def openreminder():
    window.destroy()
    os.system("py reminder.py " + user)
    return True


backgroundLabel = Label(window, image=bgImg)
backgroundLabel.place(x=0, y=0, relheight=1, relwidth=1)

btnManageMember = Button(text="Manage Member", command=openManageMember)
btnAddNotice = Button(text="Add Notice", command=openAddNotice)
btnViewComplaints = Button(text="View Complaints", command=openViewComplaints)
btnBill = Button(text="Bill", command=openBill)
btnreminder = Button(text="Reminder", command=openreminder)

btnManageMember.grid(row=0, column=0, padx=5, pady=5, sticky=N)
btnAddNotice.grid(row=1, column=0, padx=5, pady=5, sticky=N)
btnViewComplaints.grid(row=2, column=0, padx=5, pady=5, sticky=N)
btnBill.grid(row=3, column=0, padx=5, pady=5, sticky=N)
btnreminder.grid(row=4, column=0, padx=5, pady=5, sticky=N)

user = sys.argv[1]

# btnLogin.pack()
window.geometry('400x400')
window.mainloop()
